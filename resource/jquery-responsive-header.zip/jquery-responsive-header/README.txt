A Pen created at CodePen.io. You can find this one at https://codepen.io/Brolik/pen/XjawYY.

 Not completely finished yet and having some problems moving the social icons to the right of the nav which is how they are coded in the html.